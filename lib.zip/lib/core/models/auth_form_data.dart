class AuthFormData {
  String name = '';
  String email = '';
  String password = '';
}
