class ProductFormData {
  String name;
  String type;
  String brand;
  String description;

  ProductFormData({
    this.name = '',
    this.type = '',
    this.brand = '',
    this.description = '',
  });
}
